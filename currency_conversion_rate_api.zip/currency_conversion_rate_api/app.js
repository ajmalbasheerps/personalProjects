var https = require('https');
const express = require("express");
const app = express();
const request = require("request");
app.set('view engine','ejs');

app.listen(2010,()=> {
    console.log("Assigment 2 listening to port 2000");
});

app.get('/convert',(req,res)=> {
    request('https://free.currconv.com/api/v7/convert?q=USD_PHP&compact=ultra&apiKey=ffd8fe543ec349fb8059',(error,response,body)=>{
        const info = JSON.parse(body);
        var value = "USD_PHP";
        var fromCurr ="USD";
        var toCurr ="PHP";
        if(error){
            console.log(error);
        }
        else {
            console.log(response.statusCode);
            console.log(value)
            console.log(info["USD_PHP"]);
            console.log(info[value]);
            res.render("data.ejs",{
                Currency : info,
                value : value,
                fromCurr :fromCurr,
                toCurr:toCurr
            });
        }
    });
});
app.get('/converts',(req,res)=> {
    const from = req.query.CURR_FR;
    const to = req.query.CURR_TO;
    
    request('https://free.currconv.com/api/v7/convert?q='+from+'_'+to+'&compact=ultra&apiKey=ffd8fe543ec349fb8059',(error,response,body)=>{
        const info = JSON.parse(body);
        if(error){
            console.log(error);
        }
        else {
            var fromCurr=from;
            var toCurr=to;
            var value= fromCurr+"_"+toCurr;
            console.log(value)
            console.log(info[value]);
            console.log(response.statusCode);
            res.render("data.ejs",{
                Currency : info,
                value : value,
                fromCurr :fromCurr,
                toCurr : toCurr
            });
        }
    });
});
