Simple Currency Conversion rate Api using Node js and ejs
==========================================

The project provides the currency conversion rate between two country's currency.
It takes two country codes code,
one for the base country currency code and 
the second for the target country currency code.
Then the conversion rate between the country code will be displayed.

instruction
------------
1.Copy the file
2.Extract the zip
3.for local instantiation, use Git bash teminal.
4. use nodemon app.js to run the project and check the result in "http://localhost:2010/convert"
 -- user must instal express, nodemon, ejs and request packages