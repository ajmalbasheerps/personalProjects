const express = require("express");
const app = express();
const request = require("request");
app.set('view engine','ejs');

app.listen(2000,()=>{
    console.log("App Running in Port 2000");
});

app.get('/weather',(req,res)=>{
    request("http://api.weatherstack.com/current?access_key=70d0812e9e0177d3b7bfe8d0bfc11ed0&query=New York",(error,response,body)=>{
        const info = JSON.parse(body);
        if(error){
            console.log(error);
        }
        else {
            console.log(response.statusCode);
            res.render("data.ejs",{
                weather : info
            });
        }
    });
});

app.get('/weathers',(req,res)=>{
    const city = req.query.city;
    request("http://api.weatherstack.com/current?access_key=70d0812e9e0177d3b7bfe8d0bfc11ed0&query="+city,(error,response,body)=>{
        const info = JSON.parse(body);
        if(error){
            console.log(error);
        }
        else {
            console.log(response.statusCode);
            res.render("data.ejs",{
                weather : info
            });
        }
    });
});