Simple Weather Api using Node js and ejs
==========================================

The project basically inputs a city name and fetch the current weather attibutes 
of the particular city from weatherstack api and dislays the details in the api
web page.

instruction
------------
1.Copy the file
2.Extract the zip
3.for local instantiation, use Git bash teminal.
4. use nodemon app.js to run the project and check the result in "http://localhost:2000/weather"
 -- user must instal express, nodemon, ejs and request packages