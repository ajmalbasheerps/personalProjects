const express = require("express");
const request = require("request");
const app = express();
app.set('view engine','ejs');

app.listen(2000, ()=> {
    console.log('listening to 2000');
});

app.get('/movie', (req,res) =>{
    request('http://www.omdbapi.com/?t=titanic&apikey=8186acda',(error,response,body) => {
        const data = JSON.parse(body);
        if(error) {
            console.log(error);
        }
        else {
            res.render("movie.ejs", {
                data : data
            });
        }
    });
});

app.get('/movies', (req,res) =>{
    const title = req.query.movie;
    console.log(title);
    request('http://www.omdbapi.com/?t='+title+'&apikey=8186acda',(error,response,body) => {
        const data = JSON.parse(body);
        if(error) {
            console.log(error);
        }
        else {
            res.render("movie.ejs", {
                data : data
            });
        }
    });
});