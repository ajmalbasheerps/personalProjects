Simple movies search Api using Node js and express
==========================================

Movies Search Node JS Application using NodeJs and Express  which displays movie data like movie title, genre, directors, actors etc.
The api also has a form for Searching Movie by Title and to retrive and display movie information.

instruction
------------
1.Copy the file
2.Extract the zip
3.for local instantiation, use Git bash teminal.
4. use nodemon app.js to run the project and check the result in "http://localhost:2000/movie"
 -- user must instal express, nodemon, ejs and request packages