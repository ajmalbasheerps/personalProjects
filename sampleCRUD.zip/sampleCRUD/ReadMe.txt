Simple Weather Api using Node js and ejs
==========================================

The project is a Node Js application which implements simple CRUD operations liasing Mongo DB.
This is simple employment management application which enables the user to 
display the employees, 
update their details,
delete employees and 
to creat new employee in to DB

instruction
------------
1.Copy the file
2.Extract the zip
3.for local instantiation, use Git bash teminal.
4. use nodemon app.js to run the project and check the result in "http://localhost:2000/all"
 -- user must instal express, nodemon, ejs and request packages
5.please edit the mongoose.connect parameter with you own credentials