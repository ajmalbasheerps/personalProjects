const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
app.set("view engine","ejs");
app.use(express.static("public"));
app.use(bodyParser.urlencoded({extended:true}));
app.listen(2000,()=>{
    console.log("Running at port 2000!");
});
mongoose.connect("mongodb+srv://bestbuy:bestbuy@cluster0.sq6hk.mongodb.net/bestbuydb?retryWrites=true&w=majority",
{useUnifiedTopology:true,useNewUrlParser:true}, (error)=>{
    if(error){
        console.log(error);
        console.log("Mongodb not connected");
    }
    else{
        console.log("mongod db connected !!!");
    }
});

const empSchema = mongoose.Schema({
    name: String,
    city: String,
    contact: String,
    email: String,
    salary: Number
        
});

const emp = mongoose.model("emp",empSchema);


app.get("/all",(req,res)=>{

    emp.find({},(error,dataFound)=>{
        if(error){
            console.log(error);
            console.log("Data not Retrieved from Mongo db");
        }
        else {
            
            res.render("display.ejs",{
                emps : dataFound
            });
        }
    })

});

app.get("/delete/:id",(req,res)=>{
    var id = req.params.id;
    emp.findByIdAndDelete(id,(error,empDeleted)=>{
        if(error){
            console.log(error);
            console.log("Error while deletion");
        }
        else{
            console.log("Successfully deleted");
            console.log("Deleted employee ::"+empDeleted);
            res.redirect("/all");
        }
    });
});

app.get("/edit/:id",(req,res)=> {
    var id = req.params.id;
    emp.findById(id,(error,empFound)=>{
        if(error){
            console.log(error);
            console.log("Data not found");
        }
        else{
            console.log("Employee data found Successfully");
            console.log("Employee found  ::"+empFound);
            res.render("edit.ejs",{
                info:empFound
            })
        }
    });
});

app.post("/update/:id",(req,res)=>{
    var id = req.params.id;
    const upd_employee = req.body;
    emp.findByIdAndUpdate(id,{
        name:upd_employee.name,
        city:upd_employee.city,
        salary:upd_employee.salary,
        contact:upd_employee.contact,
        email:upd_employee.email

    },(error,updEmp)=>{
        if(error){
            console.log(error);
            console.log("Employee not update");
        }
        else{
            console.log("Successfully updated");
            console.log("Updated employee ::"+updEmp);
            res.redirect("/all");
        }
    });
});

app.get("/add",(req,res)=>{
    res.render("add.ejs");

});

app.post("/add",(req,res)=> {
    const add_employee = req.body;
    emp.create({
        name:add_employee.name,
        city:add_employee.city,
        salary:add_employee.salary,
        contact:add_employee.contact,
        email:add_employee.email

    }, (error,empCreated)=>{
        if(error){
            console.log(error);
            console.log("emp is not created employee");
        }
        else {
            console.log("emp created !::"+empCreated);
            res.redirect("/all");
        }
    });
});